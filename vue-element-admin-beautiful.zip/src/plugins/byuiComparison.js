import byuiComparison from "zx-comparison";

export default byuiComparison;
