import byuiSwiper from "zx-swiper";

export default byuiSwiper;
